import math

f = open("result.txt", "w")

sresult = ""

radius = 3
n = 32
degree = 360/n

for i in range(n):
    x = float(math.cos(0 + degree*i) * radius) * 10000000
    y = float(math.sin(0 + degree*i) * radius) * 10000000
    
    sresult += "\n"
    sresult += "particle minecraft:cloud ~ ~0.2 ~ ^{:.4f} ^ ^{:.4f} 0.0000001 0 normal".format(x,y) #{:.4f}



f.write(sresult)

f.close()