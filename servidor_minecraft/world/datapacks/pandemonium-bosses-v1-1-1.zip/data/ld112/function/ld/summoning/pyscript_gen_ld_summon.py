f= open("generation.txt","w+")
#f=open("generation.txt","a+")

#bd
for i in range(30):
     f.write('summon item_display ~ ~' + str(i) + ' ~ {teleport_duration:5,Tags:["ldragon","ldsegs","ldseg' + str(i+1) + '","lddisp","ld_init"],item:{id:"minecraft:white_dye",count:1,components:{"minecraft:custom_model_data":113}}}\n')
     
f.write('\n')

#vex
for i in range(30):
     f.write('summon vex ~ ~' + str(i) + ' ~ {CustomNameVisible:0b,CustomName:\'{"text":"Deathmire"}\',Silent:1b,NoAI:1b,Health:400f,LifeTicks:20000000,Tags:["ldragon","ldhitbox","ldsegs","ldseg' + str(i+1) + '","ld_init"],active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:20000000,show_particles:0b},{id:"minecraft:resistance",amplifier:0,duration:20000000,show_particles:0b},{id:"minecraft:fire_resistance",amplifier:1,duration:20000000,show_particles:0b}],ArmorItems:[{id:"minecraft:netherite_boots",count:1,components:{"minecraft:enchantments":{levels:{"minecraft:blast_protection":4}}}},{id:"minecraft:netherite_leggings",count:1,components:{"minecraft:enchantments":{levels:{"minecraft:blast_protection":4}}}},{id:"minecraft:netherite_chestplate",count:1,components:{"minecraft:enchantments":{levels:{"minecraft:blast_protection":4}}}},{id:"minecraft:netherite_helmet",count:1,components:{"minecraft:enchantments":{levels:{"minecraft:blast_protection":4}}}}],ArmorDropChances:[-327.670F,-327.670F,-327.670F,-327.670F],attributes:[{id:"minecraft:generic.max_health",base:400},{id:"minecraft:generic.scale",base:2}]}\n')
     
f.write('\n')


f.close()

