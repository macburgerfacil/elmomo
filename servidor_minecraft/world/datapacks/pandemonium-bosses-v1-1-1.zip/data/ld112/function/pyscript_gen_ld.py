f= open("generation.txt","w+")
#f=open("generation.txt","a+")

#bd
for i in range(30):
     f.write('summon item_display ~ ~ ~' + str(i*(-1)) + ' {teleport_duration:5,Tags:["ldragon","ldsegs","ldseg' + str(i+1) + '","lddisp","ld_init"],item:{id:"minecraft:white_dye",count:1,components:{"minecraft:custom_model_data":113}}}\n')
     
f.write('\n')

#vex
for i in range(30):
     f.write('summon vex ~ ~ ~' + str(i*(-1)) + ' {Silent:1b,NoAI:1b,Health:400f,LifeTicks:20000000,Tags:["ldragon","ldhitbox","ldsegs","ldseg' + str(i+1) + '","ld_init"],active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:20000000,show_particles:0b,show_icon:0b,ambient:0b}],attributes:[{id:"minecraft:generic.max_health",base:400},{id:"minecraft:generic.scale",base:2}]}\n')
     
f.write('\n')


#trailing
for i in range(30):
     f.write('execute if entity @s[tag=ldseg' + str(i+2) + ',tag=this] at @e[tag=ldseg' + str(i+1) + ',type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1\n')

f.close()

