

import math

f = open("result.txt", "w")

sresult = ""

width = 3
height = 3
depth = 3

x_start = -1
z_start = -1
y_start = 0

for i in range(height):
    y = y_start
    y += i
    for j in range(width):
        x = x_start
        x += j
        for k in range(height):
            z = z_start
            z += k
            
            sresult += "\n"
            sresult += "execute unless block ~{} ~{} ~{} #minecraft:wither_immune run setblock ~{} ~{} ~{} air destroy".format(x,y,z,x,y,z) #{:.4f}



f.write(sresult)

f.close()