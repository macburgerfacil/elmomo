import math



sresult = ""

radius = 1.8
n = 32
degree = 360/n


f = open("ccircle"+str(radius)+".mcfunction", "w")

for i in range(n):
    x = float(math.cos(0 + degree*i) * radius)
    y = float(math.sin(0 + degree*i) * radius)
    
    sresult += "\n"
    sresult += "particle dust{color:[0.573,0.031,1.000],scale:1} ^" + str(x) + " ^" + str(y) + " ^ 0 0 0 0.001 1"

f.write(sresult)

f.close()

#.format(x,y) #{:.4f}
#particle soul_fire_flame ~{:.4f} ~ ~{:.4f} 0 0 0 0.001 1
#particle dust%<color:[0.573,0.031,1.000],scale:1>% ^{:.4f} ^{:.4f} ^ 0 0 0 0.001 1