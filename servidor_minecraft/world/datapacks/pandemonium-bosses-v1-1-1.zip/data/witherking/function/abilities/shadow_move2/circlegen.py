import math

f = open("result.txt", "w")

sresult = ""

radius = 9
n = 12
degree = 360/n
starting_degree = 45

for i in range(n):
    x = float(math.cos(starting_degree + degree*i) * radius)
    y = float(math.sin(starting_degree + degree*i) * radius)
    
    sresult += "\n"
    sresult += "summon lightning_bolt ~{:.4f} ~ ~{:.4f}".format(x,y) #{:.4f}

f.write(sresult)

f.close()


#particle soul_fire_flame ~{:.4f} ~ ~{:.4f} 0 0 0 0.001 1